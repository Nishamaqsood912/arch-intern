#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    char choice;

    // Seed the random number generator
    srand(time(0));

    do {
        int die1 = rand() % 6 + 1;
        int die2 = rand() % 6 + 1;

        cout << "\nYou rolled:\n";
        cout << "Die 1: " << die1 << endl;
        cout << "Die 2: " << die2 << endl;
        cout << "Total: " << die1 + die2 << endl;

        cout << "\nRoll again? (y/n): ";
        cin >> choice;

    } while (choice == 'y' || choice == 'Y');

    cout << "Thanks for playing! ??\n";
    return 0;
}

